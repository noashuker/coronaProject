import { Button, IconButton, List, ListItemIcon, ListItemText, makeStyles, Tabs, TextField, Typography } from "@material-ui/core";
import axios from "axios";
import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import ArrowCircleRightIcon from '@mui/icons-material/ArrowCircleRight';
import { ListItemButton } from "@mui/material";
import WorkIcon from '@mui/icons-material/Work';
import WorkOffIcon from '@mui/icons-material/WorkOff';
import DeleteIcon from '@mui/icons-material/Delete';
import Station from "../classes/Station";


interface Details {
    isDetails: boolean,
    station: Station,
}

export function ViewStation(props: any): JSX.Element {

    let stations = props.stations as Station[];

    const [open, setOpen] = useState(false);
    const handleOpen = () => setOpen(true);
    const handleClose = () => setOpen(false);

    const [details, setDetails] = useState<Details>({
        isDetails: false,
        station: { StationId: 0, UserId: 0, Location_X: 0, Location_Y: 0},
    });
    const getStation = async (stationId: number, status: boolean) => {
        if (status) {
            var promise = axios.get("https://localhost:44399/api/StationById/" + stationId);
            var response = await promise;
            console.log(response.data);
            setDetails({ isDetails: true, station: response.data });
        }
        else {
            setDetails({ isDetails: false, station: { StationId: 0, UserId: 0, Location_X: 0, Location_Y: 0 } });
        }
    }

    const [update, setUpdate] = useState(false);
    const handleUpdate = () => setUpdate(true);

    const { register, handleSubmit, formState: { errors } } = useForm<Station>();

    const styles = makeStyles({
        textBox: { margin: "1.1%" },
        width: { width: "10rem" }
    });

    const useStyle = styles();

    return (
        <div>
            {!details.isDetails ?
                <Tabs orientation="vertical">
                    <List component="nav" aria-label="mailbox folders">
                        {stations.map(s =>
                            <ListItemButton divider onClick={() => getStation(s.StationId, true)}>
                                {/* {s.IsTrackUsed ?
                                    <IconButton onClick={handleOpen}>
                                        <WorkIcon></WorkIcon>
                                    </IconButton>
                                    : <ListItemIcon>
                                        <WorkOffIcon></WorkOffIcon>
                                    </ListItemIcon>} */}
                                <ListItemIcon>
                                    <WorkOffIcon></WorkOffIcon>
                                </ListItemIcon>
                                <ListItemText primary={`מיקום תחנה: ${s.Location_X}`} style={{ textAlign: "right" }}></ListItemText>
                                <IconButton>
                                    <DeleteIcon />
                                </IconButton>
                            </ListItemButton>
                        )}
                    </List>
                </Tabs> :
                <div>
                    <IconButton onClick={() => getStation(0, false)}>
                        <ArrowCircleRightIcon style={{ textAlign: "right", fontSize: "1.5em" }} />
                    </IconButton>
                   
                        <form className="station-details">
                            <Typography component="h1" variant="h5">
                                פרטי תחנה
                            </Typography>
                            <TextField className={useStyle.textBox} id="filled-basic" label="מיקום תחנה" variant="filled" value={details.station.Location_X} disabled></TextField><br />
                            <TextField className={useStyle.textBox} id="filled-basic" label="שעת תחילת פעילות" variant="filled" value={details.station.Location_Y} disabled></TextField><br />
                           </form> :
                       
                    <form className="package-details" style={{ marginTop: "3%" }}>
                        <Typography component="h1" variant="h5">
                            פרטי חבילה
                        </Typography>
                       
                          </form>
                        </div>
   }   </div>
    )
}