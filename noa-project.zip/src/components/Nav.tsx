import "./Nav.css";
import { Link } from "react-router-dom";
import { AppBar } from "@mui/material";
import { colors, createTheme, rgbToHex } from "@material-ui/core";
import { cyan } from "@material-ui/core/colors";
import Logo from "../Logo";
 import HomeRoundedIcon from '@mui/icons-material/HomeRounded';
import SettingsIcon from '@mui/icons-material/Settings';
 import AddCircleOutlineIcon from '@mui/icons-material/AddCircleOutline';
 import PersonAddIcon from '@mui/icons-material/PersonAdd';
 import CalendarMonthIcon from '@mui/icons-material/CalendarMonth';
 
function Nav(): JSX.Element {
 
    return (
        <AppBar sx={{bgcolor:cyan[600],textAlign:'left'}}>
            <ul className="">
               {/* <Link to='/' className="nav-links m" >
                   <HomeRoundedIcon></HomeRoundedIcon> 
                    <li className="nav-links">Home</li>

                </Link> */}

                <Link to='/signUp' className="nav-links" >
                    <PersonAddIcon></PersonAddIcon> 
                    <li className="nav-links">Sign Up</li>
                </Link>

                <Link to='/logIn' className="nav-links" >
                     <AddCircleOutlineIcon></AddCircleOutlineIcon> 
                    <li className="nav-links">Sign In</li>
                </Link>

                <Link to='/myDays' className="nav-links" >
                     <CalendarMonthIcon></CalendarMonthIcon> 
                    <li className="nav-links">myDays</li>
                </Link>
                
                <Link to='/preferDay' className="nav-links" >
                    <AddCircleOutlineIcon></AddCircleOutlineIcon> 
                    <li className="nav-links">עדפות יום</li>
                </Link>
                

            </ul>
        </AppBar>
    );
}

export default Nav;