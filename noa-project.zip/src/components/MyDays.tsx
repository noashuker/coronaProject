import { makeStyles } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import axios from 'axios';
import GraphOptions from '../classes/GraphOptions';
import { useForm } from 'react-hook-form';
import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';

const useStyles = makeStyles({
  table: {
    minWidth: 650,
  },
});

function createData(sanday: string, monday: string, tursday: string, wendsday: string, thursday: string, friday: string) {
  return { sanday, monday, tursday, wendsday, thursday, friday };
}

// const rows = [
//   createData('Frozen yoghurt', 159, 6.0, 24, 4.0),
//   createData('Ice cream sandwich', 237, 9.0, 37, 4.3),
//   createData('Eclair', 262, 16.0, 24, 6.0),
// ];

export default function MyDay() {
  var { userId } = useParams();
  const classes = useStyles();
  const [rows, setRows] = React.useState([])

  React.useEffect(() => {

    console.log(userId);
    axios.get(`https://localhost:44323/api/Scheduling/${7}`)
      .then(res => {
        debugger
        setRows(res.data)
      })
      .catch(err => console.log(err))
  }, [])

  return (
    <TableContainer component={Paper} style={{ marginTop: 100 }}>
      <Table className={classes.table} aria-label="caption table">
        {/* <caption>A basic table example with a caption</caption> */}
        <TableHead>
          <TableRow>
            <TableCell>sunday</TableCell>
            <TableCell align="right">monday</TableCell>
            <TableCell align="right">tursday</TableCell>
            <TableCell align="right">wendsday</TableCell>
            <TableCell align="right">thursday</TableCell>
            <TableCell align="right">friday</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {(rows as GraphOptions[][]).map((row) =>
            <TableCell>
              {row.map((item, index) =>
              (
                <TableRow key={item.DayId}>
                  {item.ChildName} {item.ChildLastName}
                </TableRow>
              )
              )
              }
            </TableCell>

          )}
        </TableBody>
      </Table>
    </TableContainer>
    // <div>
    // <table>
    // <tr>sunday</tr>
    //        <tr >monday</tr>
    //          <tr >tursday</tr>
    //         <tr >wendsday</tr>
    //         <tr>thursday</tr>
    //       <tr >friday</tr>
    // </table></div>
  );
}