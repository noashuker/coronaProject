import { Box, Collapse, Divider, IconButton, ListItem, ListItemIcon, ListItemText, Tabs } from "@material-ui/core";
import { Link, useNavigate, useParams } from "react-router-dom";
import List from '@mui/material/List';
import DirectionsCarIcon from '@mui/icons-material/DirectionsCar';
import LocationOnIcon from '@mui/icons-material/LocationOn';
import MedicalServicesIcon from '@mui/icons-material/MedicalServices';
import { Button, ListItemButton } from "@mui/material";
import { useEffect, useState } from "react";
import { ExpandLess, ExpandMore } from "@material-ui/icons";
import WorkIcon from '@mui/icons-material/Work';
import AddIcon from '@mui/icons-material/Add';
import './Account.css';
import PersonIcon from '@mui/icons-material/Person';
import axios from "axios";
import { ViewStation } from "./ViewStation";
import { ViewDriverTrack } from "./ViewRoute";

export default function RequestAccount(): JSX.Element {

    var { FName } = useParams();
    var { Password } = useParams();
    var { userId } = useParams();
    
    const navigate=useNavigate();
const MyDay=()=>
{
  navigate(`MyDays/${userId}/`);
}
return(
    <div>
    <h1>אזור אישי {FName} </h1>

    <Link to="/UpdateAdress ">
        <Button id="button" variant="contained" type='submit'
            color="primary"//***********איך גורמים שבלחיצה על שליחה, יעורר את הפעולה שנמצאת בפרוגרס */
        >
            לעידכון כתובת
        </Button>
    </Link>
    
        <Button id="button" variant="contained" type='submit' onClick={()=>MyDay()}
            color="primary" //***********איך גורמים שבלחיצה על שליחה, יעורר את הפעולה שנמצאת בפרוגרס */
        >
            האישפוזים שלי
        </Button>
   
</div>
)
}