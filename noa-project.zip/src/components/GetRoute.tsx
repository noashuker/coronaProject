import { IconButton, List, ListItemIcon, ListItemText, Tabs } from "@material-ui/core";
import DeleteIcon from '@mui/icons-material/Delete';
import axios from "axios";
import { useState } from "react";
import WorkIcon from '@mui/icons-material/Work';
import WorkOffIcon from '@mui/icons-material/WorkOff';
import { ListItemButton } from "@mui/material";
import DriverTrack from "../classes/Driver";
import { ViewDriverTrack } from "./ViewRoute";

interface Details {
    isDetails: boolean,
    driverTrack: DriverTrack,
}

export function GetTracks(props: any): JSX.Element {

    const tracks: DriverTrack[] = props.tracks as DriverTrack[];

    const [open, setOpen] = useState(false);
    const handleOpen = () => setOpen(true);
    const handleClose = () => setOpen(false);

    const [details, setDetails] = useState<Details>({
        isDetails: false,
        driverTrack: { DriverTrackId: 0, UserId: 0, SourceTrack_X: 0, SourceTrack_Y: 0, DestinationTrack_X: 0, DestinationTrack_Y: 0, DepartureTime: new Date(), Stations:[] },
    });
    const getDriverTrack = async (driverTrackId: number) => {
        var promise = axios.get("https://localhost:44399/api/DriverTrackByTrackId/" + driverTrackId);
        var response = await promise;
        console.log(response.data);
        setDetails({ isDetails: true, driverTrack: response.data });
    }

    return (
        <div>
            {!details.isDetails ?
                <Tabs orientation="vertical">
                    <List component="nav" aria-label="mailbox folders">
                        {tracks.map(t =>
                            <ListItemButton divider onClick={() => getDriverTrack(t.DriverTrackId)}>
                               
                                    <IconButton onClick={handleOpen}>
                                        <WorkIcon></WorkIcon>
                                    </IconButton>
                                    : <ListItemIcon>
                                        <WorkOffIcon></WorkOffIcon>
                                    </ListItemIcon>
                                <ListItemText primary={`מ${t.DestinationTrack_X} ל${t.DestinationTrack_Y}`} style={{ textAlign: "right" }}></ListItemText>
                                <IconButton>
                                    <DeleteIcon />
                                </IconButton>
                            </ListItemButton>
                        )
                           }   </List>
                </Tabs> :
                <ViewDriverTrack driverTrack={details.driverTrack} tracks={tracks} />}
        </div>
    )
}