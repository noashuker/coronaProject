
import Avatar from '@mui/material/Avatar';
import Button from '@mui/material/Button';
import CssBaseline from '@mui/material/CssBaseline';
import TextField from '@mui/material/TextField';
import Link from '@mui/material/Link';
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Container from '@mui/material/Container';
import { createStyles, createTheme, makeStyles, Theme, ThemeProvider } from '@mui/material/styles';
import People from '../classes/People';
import axios from 'axios';
import { useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { useNavigate } from 'react-router-dom';
import { useEffect } from 'react';
import Logo from '../Logo';
import { amber } from '@material-ui/core/colors';

interface IsAccount {
  isAccount: boolean,
  userDetails: People
}
interface IPlace {
  address: string,
  lat: number,
  lng: number,
}
const theme = createTheme();

export default function SignUp() : JSX.Element {

  const [values, setValues] = useState<IsAccount>({
      isAccount: false,
      userDetails: {ParentId:0, FirstName:"", LastName:"", Pel:"", Mail:"" , password:"" , CoordinateX:0 ,CoordinateY:0,TargetCoordinateX:0,TargetCoordinateY:0,NumEmptyPlace:0 ,NumPoint:0,Address:"",DestinationAddress:""}
  });

  const changeValues = (prop: IsAccount) => {
      setValues({ ...prop })
  };

const navigate=useNavigate();
const add=(userId:number)=>
{
  navigate(`/AddChild/${userId}`);
}

// const useStyles = makeStyles((theme: Theme) =>
//         createStyles({
//             textField: {
//                 marginLeft: theme.spacing(1),
//                 marginRight: theme.spacing(1),
//                 width: 200,
//             },
//         }),
//     );
// const classes = useStyles();

const [save, setSave] = useState(false);
  const { register, handleSubmit, formState: { errors } } = useForm<People>();

  const addUser = async (data: People) => {
     
      data.CoordinateX = placeS.lat;
      data.CoordinateY = placeS.lng;
      data.TargetCoordinateX=placeD.lat;
      data.TargetCoordinateY=placeD.lng;
      var promise = axios.post("https://localhost:44323//api/Parent/", data);
      var userPromise = await promise;
      console.log(userPromise.data);
      var response:number= userPromise.data;
      console.log("add user!!!!");
      add(response);
      var value: IsAccount = { isAccount: true, userDetails: data };
      changeValues(value);
  }
  const [placeS, setPlaceS] = useState<IPlace>({
        address: "",
        lat: 0,
        lng: 0,
    });
    const [placeD, setPlaceD] = useState<IPlace>({
        address: "",
        lat: 0,
        lng: 0,
    });
    const placeInputRefS = useRef<HTMLInputElement>(null);
    const placeInputRefD = useRef<HTMLInputElement>(null);
    const options = {
        componentRestrictions: { country: "il" },
        fields: ["all"],
    };
    const getPlaces = () => {
        if (placeInputRefS.current) {
            let autocomplete = new google.maps.places.Autocomplete(placeInputRefS.current, options);
            google.maps.event.addListener(autocomplete, "place_changed", function () {
                let place = autocomplete.getPlace();
                place.geometry?.location?.lat();
                setPlaceS({
                    address: place.formatted_address ? place.formatted_address : "",
                    lat: place.geometry?.location?.lat() ? place.geometry?.location?.lat() : 0,
                    lng: place.geometry?.location?.lng() ? place.geometry?.location?.lng() : 0,
                });
            });
            console.log(placeS);
        }
        if (placeInputRefD.current) {
            let autocomplete = new google.maps.places.Autocomplete(placeInputRefD.current, options);
            google.maps.event.addListener(autocomplete, "place_changed", function () {
                let place = autocomplete.getPlace();
                place.geometry?.location?.lat();
                setPlaceD({
                    address: place.formatted_address ? place.formatted_address : "",
                    lat: place.geometry?.location?.lat() ? place.geometry?.location?.lat() : 0,
                    lng: place.geometry?.location?.lng() ? place.geometry?.location?.lng() : 0,
                });
            });
            console.log(placeD);
        }
    }
    useEffect(getPlaces);
    

  return (
    <ThemeProvider theme={theme}>
      <Container component="main" maxWidth="xs">
        <CssBaseline />
        <Box
          sx={{
            marginTop: 8,
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
         
          }}
        >
         <Avatar sx={{ m: 1, bgcolor: 'primary.main'  }}>
            🚍
            </Avatar>
          <Typography component="h1" variant="h5">
            Sign up
          </Typography>
          <Box component="form" noValidate onSubmit={handleSubmit(addUser)} sx={{ mt: 3 }}>
            <Grid container spacing={2}>
              <Grid item xs={12} sm={6}>
                <TextField
                  autoComplete="given-name"
                 // name="firstName"
                  required
                  fullWidth
                  id="firstName"
                  label="First Name"
                  {...register('FirstName')}
                  autoFocus
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  required
                  fullWidth
                  id="lastName"
                  label="Last Name"
                //  name="lastName"
                  autoComplete="family-name"
                  {...register('LastName')}
                />
                <br/>
              </Grid>
              <Grid item xs={12} sm={6}>
              <TextField 
               inputRef={placeInputRefS} 
                fullWidth
                label="address"
                required {...register('Address')}
               />
               
              </Grid> <br />
              <Grid item xs={12} sm={6}>
                <TextField
                  required
                  fullWidth
                  id="numOfPlaces"
                  label="Num. of places"
                //  name="adress"
                  itemType='Number'
                  {...register('NumEmptyPlace')}
                />
              <br/>
              </Grid>
           <br/>
              <Grid item xs={12} sm={6}>
              <TextField 
               inputRef={placeInputRefD} 
                fullWidth
                label="destination Address"
                required {...register('DestinationAddress')}
               />
                 
                 <br />
               
              </Grid>
              <br/>
              <Grid item xs={12} sm={6}>
                <TextField
                  required
                  fullWidth
                  id="phone"
                  label="phone Num."
              
                  itemType='Number'
                  {...register('Pel')}
                  
                />
              <br/>
              <br/>
              </Grid>
              <Grid item xs={12}>
                <TextField
                  required
                  fullWidth
                  id="email"
                  label="Email Address"
                 // name="email"
                  autoComplete="Mail"
                  {...register('Mail')}
                />
                 <br/>
              </Grid>
              <br/>
              <Grid item xs={12}>
                <TextField
                  required
                  fullWidth
                //  name="password"
                  label="Password"
                  type="password"
                  id="password"
                  autoComplete="new-password"
                  {...register('password')}
                />
              
               
              </Grid>
                <br/>
           
            <Button
              type="submit"
              fullWidth
              variant="contained"
              sx={{ mt: 3, mb: 2 ,bgcolor:amber[300],textAlign:'left'}}
            >
              Sign Up
            </Button>
            <Grid container justifyContent="flex-end">
              <Grid item>
                <Link href="/logIn" variant="body2" >
                  Already have an account? Sign in
                </Link>
              </Grid>
            </Grid>
            </Grid>
          </Box>
        </Box>
      </Container>
    </ThemeProvider>
  );
}