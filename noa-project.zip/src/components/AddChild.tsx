
import axios from "axios";
import { useForm } from "react-hook-form";
import { useNavigate, useParams } from "react-router-dom";
import Child from "../classes/Child";
import Avatar from '@mui/material/Avatar';
import Button from '@mui/material/Button';
import CssBaseline from '@mui/material/CssBaseline';
import TextField from '@mui/material/TextField';
import Link from '@mui/material/Link';
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';
import Typography from "@mui/material/Typography";
import { List } from "@material-ui/core";
import { Stack } from "@mui/material";
import "./add.css";
export default function AddChild():JSX.Element {

  var { userId } = useParams();
  const navigate=useNavigate();
const add=(userId:number)=>
{
  console.log(userId);
  navigate(`/preferDay/${userId}`);
}
var id=0;
  const { register, handleSubmit,formState:{errors} } = useForm<Child>();
        const AddChilds = async (data: Child) => {
          console.log("start")
          data.ParentId=Number(userId);
          console.log(data);
          let customerPromise = axios.post("https://localhost:44323/api/Child", data);
          let response = await customerPromise;
          console.log(response.data);
          id=response.data;
          console.log(userId);
        //  add(response.data);
      }
       

    return <div><Avatar sx={{ m: 1, bgcolor: 'gray' }}>
    🚍
    </Avatar>
  <Typography component="h1" variant="h5">
    add Children
  </Typography>
  <Box className="boxx" component="form" noValidate onSubmit={handleSubmit(AddChilds)} sx={{ mt: 3 ,width:'60%'}}>
    <Grid className="grid" >
      <Grid item xs={12} sm={6}>
        <TextField
          autoComplete="given-name"
         // name="firstName"
          required
          fullWidth
          id="firstName"
          label="First Name"
          {...register('FirstName')}
          autoFocus
        />
      
      <Button
              type="submit"
              fullWidth
              variant="contained"
              sx={{ mt: 3, mb: 2 ,bgcolor: 'coral',textAlign:'center'}}
            >
            OK
            </Button>
            <Button
             onClick={()=>{add(Number(userId))}}
              fullWidth
              variant="contained"
              sx={{ mt: 3, mb: 2 ,bgcolor: 'coral',textAlign:'center'}}
            >
            next level
            </Button>
           </Grid>
      </Grid>
          </Box>
            </div>
    

}

