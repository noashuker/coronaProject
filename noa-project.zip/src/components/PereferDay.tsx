import { makeStyles } from '@material-ui/core/styles';
import Typography from '@material-ui/core/Typography';
import Slider from '@material-ui/core/Slider';
import './perferDay.css';
import PreferDays from '../classes/PreferDays';
import { useState } from "react";
import axios from 'axios';
import { useForm } from 'react-hook-form';
import { Box } from '@material-ui/core';
import { useNavigate, useParams } from 'react-router-dom';
import { useEffect } from 'react';
import { Popper } from '@mui/material';
import { useRef } from 'react';

import Button from '@mui/material/Button';
import days from '../classes/days';
import { amber } from '@material-ui/core/colors';
import { width } from '@mui/system';
interface IsAccount {
    isAccount: boolean,
    userDetails: boolean
  }
  
export default function AddPerfers() : JSX.Element {


    const [values, setValues] = useState<IsAccount>({
        isAccount: false,userDetails:false});

   const changeValues = (prop: IsAccount) => {
          setValues({ ...prop })
      };
      const [save, setSave] = useState(false);
  const { register, handleSubmit, formState: { errors } } = useForm<days>();
  const useStyles = makeStyles({
    root: {
      width: 300,
    },
  });
   
  function valuetext(value: number) {
    return `${value}`;
  }
  var { userId } = useParams();
  
const AddPerfer = async (data: days) => {  

       if(data.one+data.two+data.three+data.foure+data.five+data.six<21)
alert(
  "you choose a same priority"
)
     else
if(data.one+data.two+data.three+data.foure+data.five+data.six>=21)
{  data.userId=Number(userId);
    var promise = axios.post("https://localhost:44323//api/PreferabilityDay", data);
    var userPromise = await promise;
    var response:number= userPromise.data;
    console.log("add prefer!!!!");
    var value: IsAccount = { isAccount: true, userDetails: false };
    changeValues(value);}
}
const classes = useStyles();
  return (
    <div id='desta'>
  
    <Box component="form"  onSubmit={handleSubmit(AddPerfer)} 
      sx={{ width: 300 }
   
    }>
       
          <h3>Mark your preferences for the days of the week. Pay attention
Do not repeat the priority level you have already selected</h3>
      <Typography id="discrete-slider" gutterBottom>
        Sunday
      </Typography>
     
      <Slider   {...register("one")}
        defaultValue={1}  
        getAriaValueText={valuetext}
        aria-labelledby="discrete-slider"
        valueLabelDisplay="auto"
        step={1}
        marks
        min={1} 
        max={6}
        
    
      />
       <Typography id="discrete-slider" gutterBottom>
        Monday
      </Typography>
      <Slider  {...register("two")}
        defaultValue={1}
        getAriaValueText={valuetext}
        aria-labelledby="discrete-slider"
        valueLabelDisplay="auto"
        step={1}
        marks
        min={1}
        max={6}
      />
       <Typography id="discrete-slider" gutterBottom>
       Tuesday
      </Typography>
      <Slider  {...register("three")}
        defaultValue={1}
        getAriaValueText={valuetext}
        aria-labelledby="discrete-slider"
        valueLabelDisplay="auto"
        step={1}
        marks
        min={1}
        max={6}
      />
       <Typography id="discrete-slider" gutterBottom>
       Wednesday
      </Typography>
      <Slider  {...register("foure")}
        defaultValue={1}
        getAriaValueText={valuetext}
        aria-labelledby="discrete-slider"
        valueLabelDisplay="auto" 
        step={1}
        marks
        min={1}
        max={6}
      />
       <Typography id="discrete-slider" gutterBottom>
       Thursday
      </Typography>
      <Slider  {...register("five")}
        defaultValue={1}
        getAriaValueText={valuetext}
        aria-labelledby="discrete-slider"
        valueLabelDisplay="auto"
        step={1} 
        marks
        min={1}
        max={6}
      />
       <Typography id="discrete-slider" gutterBottom>
       Friday
      </Typography>
      <Slider  {...register("six")}
        defaultValue={1}
        getAriaValueText={valuetext}
        aria-labelledby="discrete-slider"
        valueLabelDisplay="auto"
        step={1}
        marks
        min={1}
        max={6}
      />   
     
       <Button
              type="submit"
              fullWidth
              variant="contained"
              sx={{ mt: 3, mb: 2 ,bgcolor:amber[300],textAlign:'left'}}
            >
             OK
      </Button>  
    
      </Box>
  
      </div>
  );
}