import { Button, IconButton, List, ListItemIcon, ListItemText, makeStyles, Tabs, TextField, Typography } from "@material-ui/core";
import axios from "axios";
import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import ArrowCircleRightIcon from '@mui/icons-material/ArrowCircleRight';
import { ListItemButton } from "@mui/material";
import WorkIcon from '@mui/icons-material/Work';
import WorkOffIcon from '@mui/icons-material/WorkOff';
import DeleteIcon from '@mui/icons-material/Delete';
import DriverTrackConfirmed from "../classes/DriverTRoute";
import DriverTrack from "../classes/Driver";
interface Details {
    isDetails: boolean,
    driverTrack: DriverTrackConfirmed,
}

export function ViewDriverTrack(props: any): JSX.Element {

    let tracks = props.tracks as DriverTrackConfirmed[];

    const [open, setOpen] = useState(false);
    const handleOpen = () => setOpen(true);
    const handleClose = () => setOpen(false);

    const [details, setDetails] = useState<Details>({
        isDetails: false,
        driverTrack: { DriverTrack: { DriverTrackId: 0, UserId: 0, SourceTrack_X: 0, SourceTrack_Y: 0, DestinationTrack_X: 0, DestinationTrack_Y: 0, DepartureTime: new Date(), Stations:[] }, IsConfirmed: false, DriverSubStations: [""] },
    });
    const getDriverTrack = async (driverTrackId: number, status: boolean,) => {
        if (status) {
            var promise = axios.get("https://localhost:44399/api/DriverTrackByTrackId/" + driverTrackId );
            var response = await promise;
            console.log(response.data);
            setDetails({ isDetails: true, driverTrack: response.data });
        }
        else {
            setDetails({ isDetails: false, driverTrack: { DriverTrack: { DriverTrackId: 0, UserId: 0, SourceTrack_X: 0, SourceTrack_Y: 0, DestinationTrack_X: 0, DestinationTrack_Y: 0, DepartureTime: new Date(),Stations:[] }, IsConfirmed: false, DriverSubStations: [""] } });
        }
    }

    const [update, setUpdate] = useState(false);
    const handleUpdate = () => setUpdate(true);

    const { register, handleSubmit, formState: { errors } } = useForm<DriverTrack>();

    const styles = makeStyles({
        textBox: { margin: "1.1%" },
        width: { width: "10rem" }
    });

    const useStyle = styles();

    return (
        <div>
            {!details.isDetails ?
                <Tabs orientation="vertical">
                    <List component="nav" aria-label="mailbox folders">
                        {tracks.map(t =>
                            <ListItemButton divider onClick={() => getDriverTrack(t.DriverTrack.DriverTrackId, true)}>
                               
                                <ListItemText primary={`מ${t.DriverTrack.DestinationTrack_X} ל${t.DriverTrack.DestinationTrack_Y}`} style={{ textAlign: "right" }}></ListItemText>
                                
                                <IconButton>
                                    <DeleteIcon />
                                </IconButton>
                            </ListItemButton>
                        )}
                    </List>
                </Tabs> :
                <div className="driverTrackDetails">
                    <IconButton onClick={() => getDriverTrack(0, false)}>
                        <ArrowCircleRightIcon style={{ textAlign: "right", fontSize: "1.5em" }} />
                    </IconButton>
                    
                        <form className="track-details">
                            <Typography component="h1" variant="h5">
                                פרטי מסלול
                            </Typography>
                            <TextField className={useStyle.textBox} id="filled-basic" label="שעת יציאה" variant="filled" value={details.driverTrack.DriverTrack.DepartureTime} disabled></TextField><br />
                             </form> :
                       
                    
                       <form>
                            <Typography component="h1" variant="h5">
                                פרטי חבילה
                            </Typography>
                            {/* <StepperSubTrack></StepperSubTrack> */}
                            <TextField className={useStyle.textBox} id="filled-basic" label="מקום איסוף החבילה" variant="filled" disabled value={details.driverTrack.DriverSubStations[0]}></TextField><br />
                            <TextField className={useStyle.textBox} id="filled-basic" label="הנחת החבילה" variant="filled" disabled value={details.driverTrack.DriverSubStations[1]}></TextField><br />
                            <Button variant="contained" color="primary" onClick={handleUpdate}>אישור השתתפות במסלול</Button>
                        </form>
                        
                    
                </div>}
        </div >
    )
}