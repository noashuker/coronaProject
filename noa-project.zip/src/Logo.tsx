import logo from "./logo.png"

export default function Logo() {
    return (
        <div className="image">
            <img src={logo} style={{width:"15rem",marginRight:"100%"}}></img>
        </div>
    )
}