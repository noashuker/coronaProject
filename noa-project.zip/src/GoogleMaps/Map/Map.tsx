import { request } from "http";
import { eventNames } from "process";
import React, { useState } from "react";
import { useEffect } from "react";
import { useRef } from "react";
import '.'
import Solution from "../../classes/Solution";
import './map.css';
type GoogleMap = google.maps.Map;
type GoogleLatLng = google.maps.LatLng;

interface IMap{
    mapType:google.maps.MapTypeId,
    mapTypeControl?:boolean;
}
interface IMarker{
    address:string;
    latitude:number;
    longitude:number;
}


export default function Map(props: any): JSX.Element {
    const graphMap: Solution[] = props.graphSolution as Solution[];
    var directionDisplay = new google.maps.DirectionsRenderer();
    var directionService = new google.maps.DirectionsService();


    const ref=useRef<HTMLDivElement>(null)
const [map, setMap] = useState<GoogleMap>();
const [marker,setMarker]=useState<IMarker>();
const startMap=():void=>{
    if(!map){
       defaultMapStart();
    }
};
useEffect(startMap,[map]);

const defaultMapStart=():void=>{
    const DefaultAdress=new google.maps.LatLng(65.5445,44.2);
    initMap(16,DefaultAdress);
};
const initMap=(zoomLevel:number,address:GoogleLatLng):void=>{
    if(ref.current)
        setMap(
            new google.maps.Map(ref.current,{
                zoom: zoomLevel,
                center: address,
                mapTypeControl: true,
                streetViewControl: false,
                zoomControl: true,
                mapTypeId: google.maps.MapTypeId.ROADMAP
            })
        );
        if (map != null)
        directionDisplay.setMap(map);
};

const addMarkers = () => {
    console.log(graphMap.length);
    var stopGeoLocation: google.maps.LatLng[] = [];
    for (let i = 0; i < graphMap.length; i++) {
        var point: google.maps.LatLng = new google.maps.LatLng(graphMap[i].Location.x, graphMap[i].Location.y);
        addMarker(point, graphMap[i]);
        stopGeoLocation.fill(point);
    }
    console.log(stopGeoLocation);
    calcRoutes(stopGeoLocation);
}

const addMarker = (location: GoogleLatLng, station: Solution) => {
    const marker = new google.maps.Marker({
        position: location,
        map: map,
        icon: "https://developers.google.com/maps/documentation/javascript/examples/full/images/beachflag.png",
    })
    google.maps.event.addListener(marker, 'click', function () {
        new google.maps.InfoWindow({
            content: station.DriverName + " " + station.FinalArrivalTime.getTime,
        }).open(map, marker);
    });
}

const calcRoutes = (stopGeoLocations: google.maps.LatLng[]) => {
    var waypts: google.maps.DirectionsWaypoint[] = [];
    stopGeoLocations.forEach(s => {
        waypts.push({
            location: s,
            stopover: true
        });
    });

    console.log(waypts);

    var request: google.maps.DirectionsRequest = {
        origin: stopGeoLocations[0],
        destination: stopGeoLocations[stopGeoLocations.length - 1],
        waypoints: waypts,
        optimizeWaypoints: true,
        travelMode: google.maps.TravelMode.DRIVING
    };

    directionService.route(request, () => (response: google.maps.DirectionsResult, status: google.maps.DirectionsStatus) => {
        if (status == google.maps.DirectionsStatus.OK) {
            directionDisplay.setDirections(response);
            var route = response.routes[0];
        }
    })
}


useEffect(addMarkers, [map]);

return(
<div className=".map-countainers">
    <div ref={ref} className="map-countainer">

    </div>
</div>);
};

