import { useEffect, useRef, useState } from "react";

interface IPlace {
    address: string,
    lat: number,
    lng: number,
}

export default function GPlace(): JSX.Element {

    const [placeS, setPlaceS] = useState<IPlace>({
        address: "",
        lat: 0,
        lng: 0,
    });

    const placeInputRef = useRef<HTMLInputElement>(null);
    const options = {
        componentRestrictions: { country: "il" },
        fields: ["all"],
    };

    const getPlaces = () => {
        if (placeInputRef.current) {
            let autocomplete = new google.maps.places.Autocomplete(placeInputRef.current, options);
            google.maps.event.addListener(autocomplete, "place_changed", function () {
                let place = autocomplete.getPlace();
                place.geometry?.location?.lat();
                setPlaceS({
                    address: place.formatted_address ? place.formatted_address : "",
                    lat: place.geometry?.location?.lat() ? place.geometry?.location?.lat() : 0,
                    lng: place.geometry?.location?.lng() ? place.geometry?.location?.lng() : 0,
                });
            });
            console.log(placeS);
        }
    }

    useEffect(getPlaces);

    return (
        <div>
            <input type="text" ref={placeInputRef} style={{ marginRight: "2em" }}></input>
        </div>
    )
}