import { Public } from "@material-ui/icons";

export default class days{

    constructor(
        public one:number,
        public two:number,
        public three:number,
        public foure:number,
        public five:number,
        public six:number,
        public userId:number
    ){}}