import DriverTrack from "./Driver";

export default class DriverTrackConfirmed {
    constructor(
        public DriverTrack: DriverTrack,
        public IsConfirmed: boolean,
        public DriverSubStations: string[]
    ) { }
}