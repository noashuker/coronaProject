export default class User{

    constructor(
         public Email:string,
          public Password:string 
          ,public FName: string,
          public LName: string
          ,public UserId:number
          ){}
}