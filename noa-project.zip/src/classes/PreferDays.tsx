export default class Child{
    constructor(
    public     DayPreferId :number,
    public     IdDay :number,
       public     LevelPriority:number,
       public     IdParent:number){
    }
}

