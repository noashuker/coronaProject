export default class Station {
    constructor(
        public StationId: number,
        public UserId: number,
        public Location_X: number,
        public Location_Y: number,
       ) { }
}