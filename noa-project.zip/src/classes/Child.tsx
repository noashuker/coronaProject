export default class Child{
    constructor(public ChildId:number,public FirstName:string,public ParentId:number){
    }
}
