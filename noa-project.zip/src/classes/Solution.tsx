import GeoLocation from "./GeoLocation";

export default class Solution{
    constructor(
        public RequestId: number,
        public DriverName: string,
        public Location: GeoLocation,
        public FinalArrivalTime: Date,
        public Edges: GeoLocation[]) { }
    }