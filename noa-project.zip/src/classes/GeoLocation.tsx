export default class GeoLocation {
    constructor(
        public x: number,
        public y: number) { }
}