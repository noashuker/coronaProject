export default class People{
   

    constructor(public ParentId:number,
         public FirstName :string,
         public LastName:string,
         public Pel:string,
         public Mail:string ,
         public password:string ,
         public NumPoint:number ,
          public NumEmptyPlace:number ,
          public CoordinateX:number,
          public CoordinateY:number,
          public TargetCoordinateX:number,
          public TargetCoordinateY:number,
          public DestinationAddress:string,
          public Address:string )
    {
    }

    }