import Station from "./Station";

export default class DriverTrack {
    constructor(
        public DriverTrackId: number,
        public UserId: number,
        public SourceTrack_X: number,
        public SourceTrack_Y: number,
        public DestinationTrack_X: number,
        public DestinationTrack_Y: number,
        public DepartureTime: Date,
        public Stations:Station[]
        ) { }
}