import GeoLocation from "./GeoLocation";

export default class GraphOptions {
    constructor(
      public  DayId:number,
        public  ChildName :string,
        public  ChildLastName:string,
        public  PhoneParent:string,
        public  NameParent:string,
        public  itake:number,
        public Edges: GeoLocation[]) { }
}