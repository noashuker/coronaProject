import React from 'react';
import Map from './GoogleMaps/Map/Map';
import './App.css';
import { useState } from 'react';
import { useEffect } from 'react';
import { loadavg } from 'os';
import { loadMapApi } from './GoogleMaps/Utils/GoogleMapsUtils';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom'
import { Home } from '@material-ui/icons';
import RequestAccount from './components/Account';
import Sign from './components/signUp';
import SignIn from './components/signIn';
import Nav from './components/Nav';

import StickyFooter from './components/footer';
import MyDays from './components/MyDays';
import PereferDay from './components/PereferDay';
import AddChild from './components/AddChild';
import AddPerfers from './components/PereferDay';

export default function App() {
  const [scriptLoaded, setScriptLoaded] = useState(false);

  useEffect(() => {
    const googleMapScript = loadMapApi();
    googleMapScript.addEventListener('load', function () {
      setScriptLoaded(true);
    })
  }, []);
  return (
    <div className="App"> 
    <Router>
    <Nav/>
    <Routes>
      <Route path="/login" element={<SignIn/>}/>
      <Route path="/SignUp" element={<Sign/>}/>
      <Route path="/MyDays/:parentId" element={<MyDays/>}/>
      <Route path='/AddChild/:userId' element={<AddChild/>}/>
      <Route path='/preferDay/:userId' element={<AddPerfers/>}/>
      {/* <Route path="/" element={<Home/>}/> */}
    </Routes>
  </Router>  
  <StickyFooter/>
 </div>
);
}


